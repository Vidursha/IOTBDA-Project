#include <Wire.h>
#include "MAX30105.h"
#include <driver/i2s.h>
#include <math.h>

MAX30105 particleSensor;

// ---------- Sensor addresses ----------
#define MAX30205_ADDR 0x4F

// ---------- I2S microphone pins ----------
#define I2S_SCK 5
#define I2S_WS  6
#define I2S_SD  7

// ---------- Window settings ----------
const unsigned long WINDOW_MS = 5000;
const unsigned long SAMPLE_DELAY_MS = 100;

// ---------- Health counters ----------
unsigned long temp_error_count = 0;
unsigned long pulse_error_count = 0;
unsigned long audio_error_count = 0;

// ---------- Audio helpers ----------
void setupI2SMic() {
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = 16000,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S,
    .intr_alloc_flags = 0,
    .dma_buf_count = 4,
    .dma_buf_len = 64,
    .use_apll = false,
    .tx_desc_auto_clear = false,
    .fixed_mclk = 0
  };

  i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_SCK,
    .ws_io_num = I2S_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = I2S_SD
  };

  i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_NUM_0, &pin_config);
}

bool readMicMetrics(float &soundRMS, float &soundPeak, float &soundStd) {
  const int sampleCount = 200;
  int32_t sample = 0;
  size_t bytesRead = 0;

  double sumSquares = 0.0;
  double sum = 0.0;
  double sumSq = 0.0;
  double peak = 0.0;

  for (int i = 0; i < sampleCount; i++) {
    esp_err_t result = i2s_read(I2S_NUM_0, &sample, sizeof(sample), &bytesRead, portMAX_DELAY);
    if (result != ESP_OK || bytesRead != sizeof(sample)) {
      audio_error_count++;
      return false;
    }

    double scaled = sample / 1000.0;
    double absVal = fabs(scaled);

    sumSquares += scaled * scaled;
    sum += scaled;
    sumSq += scaled * scaled;

    if (absVal > peak) {
      peak = absVal;
    }
  }

  soundRMS = sqrt(sumSquares / sampleCount);
  soundPeak = peak;

  double mean = sum / sampleCount;
  double variance = (sumSq / sampleCount) - (mean * mean);
  if (variance < 0) variance = 0;
  soundStd = sqrt(variance);

  return true;
}

// ---------- Temperature ----------
bool readTemperatureC(float &tempC) {
  Wire.beginTransmission(MAX30205_ADDR);
  Wire.write(0x00);
  if (Wire.endTransmission(false) != 0) {
    temp_error_count++;
    return false;
  }

  Wire.requestFrom(MAX30205_ADDR, 2);
  if (Wire.available() < 2) {
    temp_error_count++;
    return false;
  }

  uint8_t msb = Wire.read();
  uint8_t lsb = Wire.read();
  int16_t raw = (msb << 8) | lsb;

  tempC = raw / 256.0;
  return true;
}

// ---------- Pulse sensor ----------
bool readPulse(long &irValue, long &redValue) {
  irValue = particleSensor.getIR();
  redValue = particleSensor.getRed();

  // basic sanity check
  if (irValue < 0 || redValue < 0) {
    pulse_error_count++;
    return false;
  }

  return true;
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(8, 9);
  delay(300);

  // Pulse sensor init
  if (!particleSensor.begin(Wire, I2C_SPEED_STANDARD)) {
    Serial.println("ERROR: MAX3010x not found");
    while (1) {
      delay(1000);
    }
  }
  particleSensor.setup();

  // Audio init
  setupI2SMic();

  // CSV header
  Serial.println("window_index,temperature_c,ir_value,red_value,sound_rms,ir_red_ratio,sound_peak,sound_window_std,temp_read_success,pulse_read_success,audio_read_success,temp_error_count,pulse_error_count,audio_error_count");
}

void loop() {
  static unsigned long windowIndex = 0;
  windowIndex++;

  unsigned long startTime = millis();

  double tempSum = 0.0;
  double irSum = 0.0;
  double redSum = 0.0;
  double rmsSum = 0.0;
  double peakMax = 0.0;
  double stdSum = 0.0;

  int tempCount = 0;
  int pulseCount = 0;
  int audioCount = 0;

  bool tempReadSuccess = false;
  bool pulseReadSuccess = false;
  bool audioReadSuccess = false;

  while (millis() - startTime < WINDOW_MS) {
    float tempC = 0.0;
    long irValue = 0;
    long redValue = 0;
    float soundRMS = 0.0;
    float soundPeak = 0.0;
    float soundStd = 0.0;

    bool tempOk = readTemperatureC(tempC);
    bool pulseOk = readPulse(irValue, redValue);
    bool audioOk = readMicMetrics(soundRMS, soundPeak, soundStd);

    if (tempOk) {
      tempSum += tempC;
      tempCount++;
      tempReadSuccess = true;
    }

    if (pulseOk) {
      irSum += irValue;
      redSum += redValue;
      pulseCount++;
      pulseReadSuccess = true;
    }

    if (audioOk) {
      rmsSum += soundRMS;
      stdSum += soundStd;
      if (soundPeak > peakMax) {
        peakMax = soundPeak;
      }
      audioCount++;
      audioReadSuccess = true;
    }

    delay(SAMPLE_DELAY_MS);
  }

  float temperatureAvg = (tempCount > 0) ? (tempSum / tempCount) : -999.0;
  double irAvg = (pulseCount > 0) ? (irSum / pulseCount) : -1.0;
  double redAvg = (pulseCount > 0) ? (redSum / pulseCount) : -1.0;
  float soundRMSAvg = (audioCount > 0) ? (rmsSum / audioCount) : -1.0;
  float soundStdAvg = (audioCount > 0) ? (stdSum / audioCount) : -1.0;

  double irRedRatio = -1.0;
  if (redAvg > 0) {
    irRedRatio = irAvg / redAvg;
  }

  // Print one CSV row per 5-second window
  Serial.print(windowIndex);
  Serial.print(",");

  Serial.print(temperatureAvg, 2);
  Serial.print(",");

  Serial.print(irAvg, 2);
  Serial.print(",");

  Serial.print(redAvg, 2);
  Serial.print(",");

  Serial.print(soundRMSAvg, 2);
  Serial.print(",");

  Serial.print(irRedRatio, 4);
  Serial.print(",");

  Serial.print(peakMax, 2);
  Serial.print(",");

  Serial.print(soundStdAvg, 2);
  Serial.print(",");

  Serial.print(tempReadSuccess ? "true" : "false");
  Serial.print(",");

  Serial.print(pulseReadSuccess ? "true" : "false");
  Serial.print(",");

  Serial.print(audioReadSuccess ? "true" : "false");
  Serial.print(",");

  Serial.print(temp_error_count);
  Serial.print(",");

  Serial.print(pulse_error_count);
  Serial.print(",");

  Serial.println(audio_error_count);
}