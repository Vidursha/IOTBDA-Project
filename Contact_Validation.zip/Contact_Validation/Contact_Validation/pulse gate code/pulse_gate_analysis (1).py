import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("data_with_timestamps.csv")

# Separate data
no_finger = df[df['finger_label'] == 'no_finger']
finger = df[df['finger_label'] == 'finger_present']

# -----------------------------
# 1. LINE PLOT (VERY IMPORTANT)
# -----------------------------
plt.figure(figsize=(12,5))
plt.plot(df['ir_value'], label="IR Value")
plt.axvline(x=50, color='red', linestyle='--', label="Finger Start")
plt.title("IR Signal Over Time")
plt.xlabel("Sample Index")
plt.ylabel("IR Value")
plt.legend()
plt.show()

# -----------------------------
# 2. HISTOGRAM (MAIN PROOF)
# -----------------------------
plt.figure(figsize=(8,5))
plt.hist(no_finger['ir_value'], bins=30, alpha=0.5, label="No Finger")
plt.hist(finger['ir_value'], bins=30, alpha=0.5, label="Finger Present")
plt.legend()
plt.title("IR Value Distribution")
plt.xlabel("IR Value")
plt.ylabel("Frequency")
plt.show()

# -----------------------------
# 3. THRESHOLD CALCULATION
# -----------------------------
threshold = (no_finger['ir_value'].mean() + finger['ir_value'].mean()) / 2

print("\nSuggested Threshold:", threshold)

# Optional safer threshold
safe_threshold = no_finger['ir_value'].max() + 1000
print("Safe Threshold:", safe_threshold)