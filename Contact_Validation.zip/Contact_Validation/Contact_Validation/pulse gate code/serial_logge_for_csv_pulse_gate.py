import serial
import csv

PORT = "COM5"   # change this
BAUD = 115200

output_file = "data_raw.csv"

ser = serial.Serial(PORT, BAUD, timeout=1)

print("Waiting for data...")

# Define header manually (IMPORTANT)
headers = [
    "window_index",
    "temperature_c",
    "ir_value",
    "red_value",
    "sound_rms",
    "ir_red_ratio",
    "sound_peak",
    "sound_window_std",
    "temp_read_success",
    "pulse_read_success",
    "audio_read_success",
    "temp_error_count",
    "pulse_error_count",
    "audio_error_count"
]

with open(output_file, mode="w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(headers)  # write header FIRST

    while True:
        try:
            line = ser.readline().decode("utf-8").strip()

            if not line:
                continue

            print(line)

            values = line.split(",")

            # only write if correct number of columns
            if len(values) == len(headers):
                writer.writerow(values)

        except KeyboardInterrupt:
            print("\nLogging stopped.")
            break