// @ts-nocheck

import { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import {
  Activity,
  AlertTriangle,
  Database,
  HeartPulse,
  RefreshCw,
  ShieldAlert,
  Thermometer,
  Waves,
} from "lucide-react";
import "./App.css";

const API_BASE = "http://127.0.0.1:5000";

const COLORS = {
  high: "#ef4444",
  moderate: "#f59e0b",
  low: "#22c55e",
  blue: "#38bdf8",
  purple: "#a78bfa",
};

function getStressColor(state) {
  if (!state) return "#94a3b8";
  const s = state.toLowerCase();
  if (s.includes("high")) return COLORS.high;
  if (s.includes("moderate")) return COLORS.moderate;
  if (s.includes("low")) return COLORS.low;
  return "#94a3b8";
}

function formatTime(ts) {
  if (!ts) return "N/A";

  return new Date(ts).toLocaleString("en-LK", {
    timeZone: "Asia/Colombo",
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
}

function App() {
  const [latest, setLatest] = useState(null);
  const [stressDistribution, setStressDistribution] = useState([]);
  const [alertsSummary, setAlertsSummary] = useState(null);
  const [anomalySummary, setAnomalySummary] = useState(null);
  const [summaryTrends, setSummaryTrends] = useState([]);
  const [healthSummary, setHealthSummary] = useState(null);
  const [recent, setRecent] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  async function fetchDashboardData() {
    try {
      const [
        latestRes,
        distributionRes,
        alertsRes,
        anomalyRes,
        summaryTrendsRes,
        healthSummaryRes,
        recentRes,
      ] = await Promise.all([
        fetch(`${API_BASE}/api/latest`),
        fetch(`${API_BASE}/api/stress-distribution`),
        fetch(`${API_BASE}/api/alerts-summary`),
        fetch(`${API_BASE}/api/anomaly-summary`),
        fetch(`${API_BASE}/api/summary-trends`),
        fetch(`${API_BASE}/api/health-summary`),
        fetch(`${API_BASE}/api/recent`),
      ]);

      const latestData = await latestRes.json();
      const distributionData = await distributionRes.json();
      const alertsData = await alertsRes.json();
      const anomalyData = await anomalyRes.json();
      const summaryTrendsData = await summaryTrendsRes.json();
      const healthSummaryData = await healthSummaryRes.json();
      const recentData = await recentRes.json();

      setLatest(latestData);
      setStressDistribution(distributionData);
      setAlertsSummary(alertsData);
      setAnomalySummary(anomalyData);
      setHealthSummary(healthSummaryData);
      setRecent(recentData);

      setSummaryTrends(
        summaryTrendsData.map((item) => ({
          ...item,
          shortTime: new Date(item.timestamp_local || item.timestamp).toLocaleString("en-LK", {
              timeZone: "Asia/Colombo",
              month: "short",
              day: "2-digit",
              hour: "2-digit",
              minute: "2-digit",
              hour12: true,
            }),
        }))
      );

      setLastUpdated(new Date());
    } catch (error) {
      console.error("Dashboard fetch error:", error);
    }
  }

  useEffect(() => {
    fetchDashboardData();
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(fetchDashboardData, 5000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  const latestStress = latest?.ml_outputs?.stress_state || "Not Scored";
  const latestAlert = latest?.ml_outputs?.ml_alert || false;
  const latestAnomaly = latest?.ml_outputs?.anomaly_flag || false;

  const pieData = stressDistribution.map((item) => ({
    name: item.stress_state,
    value: item.count,
  }));

  const alertBarData = alertsSummary
    ? [
        { name: "No Alert", count: alertsSummary.no_alert_records },
        { name: "Alert", count: alertsSummary.alert_records },
      ]
    : [];

  return (
    <div className="dashboard">
      <header className="topbar">
        <div>
          <p className="eyebrow">IoT Stress Monitoring System</p>
          <h1>Real-Time Stress Analytics Dashboard - Caregiver 01</h1>
          <p className="subtitle">
            ESP32 C3 sensor data · MongoDB Atlas · ML-based stress insights
          </p>
        </div>

        <div className="top-actions">
          <button
            className={`toggle ${autoRefresh ? "active" : ""}`}
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            <RefreshCw size={16} />
            {autoRefresh ? "Auto Refresh ON" : "Auto Refresh OFF"}
          </button>
          <button className="refresh" onClick={fetchDashboardData}>
            Refresh Now
          </button>
        </div>
      </header>

      <section className="status-strip">
        <span className="pulse-dot"></span>
        API Connected · Last updated:{" "}
        {lastUpdated ? lastUpdated.toLocaleTimeString() : "Loading..."}
      </section>

      <section className="kpi-grid">
        <div className="kpi-card">
          <Database className="kpi-icon blue" />
          <p>Total Records</p>
          <h2>{alertsSummary?.total_records ?? "..."}</h2>
          <span>MongoDB sensor documents</span>
        </div>

        <div className="kpi-card">
          <HeartPulse
            className="kpi-icon"
            style={{ color: getStressColor(latestStress) }}
          />
          <p>Latest Stress State</p>
          <h2 style={{ color: getStressColor(latestStress) }}>
            {latestStress}
          </h2>
          <span>{formatTime(latest?.timestamp)}</span>
        </div>

        <div className="kpi-card">
          <AlertTriangle className="kpi-icon orange" />
          <p>Alert Rate</p>
          <h2>{alertsSummary?.alert_percentage ?? "..."}%</h2>
          <span>{alertsSummary?.alert_records ?? 0} alert records</span>
        </div>

        <div className="kpi-card">
          <ShieldAlert className="kpi-icon red" />
          <p>Anomaly Rate</p>
          <h2>{anomalySummary?.anomaly_percentage ?? "..."}%</h2>
          <span>{anomalySummary?.anomaly_records ?? 0} anomalies</span>
        </div>
      </section>

      <section className="latest-panel">
        <div className="latest-info">
          <h3>Latest Sensor Snapshot</h3>
          <p>
            This panel updates when new ESP32 records are inserted into MongoDB.
          </p>
        </div>

        <div className="mini-metrics">
          <div>
            <Thermometer size={18} />
            <span>Temperature</span>
            <strong>{latest?.readings?.temperature_c?.toFixed(2) ?? "--"} °C</strong>
          </div>

          <div>
            <Activity size={18} />
            <span>IR / RED Ratio</span>
            <strong>{latest?.features?.ir_red_ratio?.toFixed(3) ?? "--"}</strong>
          </div>

          <div>
            <Waves size={18} />
            <span>Sound RMS</span>
            <strong>{latest?.readings?.sound_rms?.toFixed(2) ?? "--"}</strong>
          </div>

          <div className={latestAlert ? "danger-pill" : "safe-pill"}>
            <span>Alert</span>
            <strong>{latestAlert ? "ACTIVE" : "NORMAL"}</strong>
          </div>

          <div className={latestAnomaly ? "danger-pill" : "safe-pill"}>
            <span>Anomaly</span>
            <strong>{latestAnomaly ? "YES" : "NO"}</strong>
          </div>
        </div>
      </section>

      <main className="chart-grid">
        <section className="chart-card">
          <div className="chart-header">
            <h3>Stress-State Distribution</h3>
            <p>Technique 1: behavior pattern analysis</p>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                innerRadius={70}
                outerRadius={110}
                paddingAngle={4}
              >
                {pieData.map((entry, index) => (
                  <Cell key={index} fill={getStressColor(entry.name)} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card">
          <div className="chart-header">
            <h3>ML Alert Distribution</h3>
            <p>Technique 2: learned alert states</p>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={alertBarData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="name" stroke="#cbd5e1" />
              <YAxis stroke="#cbd5e1" />
              <Tooltip />
              <Bar dataKey="count" radius={[8, 8, 0, 0]} fill="#38bdf8" />
            </BarChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card wide">
          <div className="chart-header">
            <h3>Smoothed Stress Severity Trend</h3>
            <p>Technique 5: 30-minute aggregated temporal trend</p>
          </div>

          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={summaryTrends}>
              <defs>
                <linearGradient id="stressGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="shortTime" stroke="#cbd5e1" hide />
              <YAxis stroke="#cbd5e1" domain={[0, 2]} />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="avg_stress_score"
                name="Avg Stress Score"
                stroke="#ef4444"
                fill="url(#stressGradient)"
                strokeWidth={3}
              />
            </AreaChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card wide">
          <div className="chart-header">
            <h3>Aggregated Sensor Trend Analysis</h3>
            <p>30-minute averages with dual-axis scaling</p>
          </div>

          <ResponsiveContainer width="100%" height={330}>
            <LineChart data={summaryTrends}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="shortTime" stroke="#cbd5e1" hide />
              <YAxis yAxisId="left" stroke="#cbd5e1" />
              <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="avg_sound_rms"
                name="Avg Sound RMS"
                stroke="#38bdf8"
                dot={false}
                strokeWidth={2}
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="avg_temperature"
                name="Avg Temperature"
                stroke="#22c55e"
                dot={false}
                strokeWidth={2}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="avg_ir_red_ratio"
                name="Avg IR/RED Ratio"
                stroke="#f59e0b"
                dot={false}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card wide">
          <div className="chart-header">
            <h3>Alert and Anomaly Timeline</h3>
            <p>Technique 2 + 4: grouped alert and anomaly counts</p>
          </div>

          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={summaryTrends}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="shortTime" stroke="#cbd5e1" hide />
              <YAxis stroke="#cbd5e1" />
              <Tooltip />
              <Legend />
              <Bar dataKey="alert_count" name="Alerts" fill="#f59e0b" radius={[8, 8, 0, 0]} />
              <Bar dataKey="anomaly_count" name="Anomalies" fill="#ef4444" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card">
          <div className="chart-header">
            <h3>Sensor Health Success Rate</h3>
            <p>Read success percentage per sensor</p>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={healthSummary?.sensor_success_rates || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="sensor" stroke="#cbd5e1" />
              <YAxis stroke="#cbd5e1" domain={[0, 100]} />
              <Tooltip />
              <Bar dataKey="success_rate" name="Success Rate %" fill="#22c55e" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </section>

        <section className="chart-card">
          <div className="chart-header">
            <h3>Sensor Error Counts</h3>
            <p>Total error counts recorded by each sensor</p>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={healthSummary?.error_counts || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.12)" />
              <XAxis dataKey="sensor" stroke="#cbd5e1" />
              <YAxis stroke="#cbd5e1" />
              <Tooltip />
              <Bar dataKey="errors" name="Error Count" fill="#a78bfa" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </section>
      </main>

      <section className="table-card">
        <div className="chart-header">
          <h3>Recent Readings</h3>
          <p>Latest MongoDB records with ML outputs</p>
        </div>

        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Temperature</th>
                <th>Sound RMS</th>
                <th>Stress State</th>
                <th>Alert</th>
                <th>Anomaly</th>
                <th>Source</th>
              </tr>
            </thead>

            <tbody>
              {recent.map((item) => (
                <tr key={item._id}>
                  <td>{item.timestamp_local || formatTime(item.timestamp)}</td>
                  <td>{item.readings?.temperature_c?.toFixed(2)} °C</td>
                  <td>{item.readings?.sound_rms?.toFixed(2)}</td>
                  <td>
                    <span
                      className="stress-pill"
                      style={{
                        background: getStressColor(item.ml_outputs?.stress_state),
                      }}
                    >
                      {item.ml_outputs?.stress_state || "Not Scored"}
                    </span>
                  </td>
                  <td>{item.ml_outputs?.ml_alert ? "Alert" : "Normal"}</td>
                  <td>{item.ml_outputs?.anomaly_flag ? "Anomaly" : "Normal"}</td>
                  <td>{item.ml_outputs?.model_source || "N/A"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

export default App;